Run moveDLL with admin privilages to move the dll files to the right location.

If you would like to do that manually here is the location to put all three dll files
C:\Windows\SysWOW64